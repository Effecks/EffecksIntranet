EXAMPLE:
========

#localize("this is a static string")#
#localize("this is a dynamic string {#LsDateFormat(Now())#}")#

CHANGES 0.0.6:
=============

- Complete locale list (thanks to Pierre Paridans)
- Compability with Wheels 0.9.4.

CHANGES 0.0.5:
=============

- Compability with Wheels 0.9.3.
- It would display a comment besides every "localized" message so you can see where that message was harvested (for multiple messages, it will use the first it found).
- Bug squashing.

CHANGES 0.0.4:
=============

- See above.

CHANGES 0.0.3:
=============

- Changes to the documentation.
- Compability with Wheels 0.9.1.

CHANGES 0.0.2:
=============

- Able to localize dynamic strings.
- More documentation inside the plugin's index page.

CHANGES 0.0.1:
=============

- First version of the Localizer plugin.
- Able to localize static strings.

Thanks to the wheels team!

http://www.cfwheels.com